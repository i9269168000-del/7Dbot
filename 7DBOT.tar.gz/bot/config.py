from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    bot_token: str = ""
    admin_chat_id: int = 0
    webapp_url: str = "http://localhost:5173"
    api_url: str = "http://localhost:8000"
    admin_secret: str = "change_me_in_production"

    class Config:
        env_file = "../.env"
        env_file_encoding = "utf-8"


settings = Settings()
